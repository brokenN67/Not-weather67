package com.example.notweather

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var sky: WeatherView
    private lateinit var bar: DayBar
    private lateinit var place: TextView
    private lateinit var unit: TextView
    private lateinit var summary: TextView
    private lateinit var status: TextView

    private var weather: Weather? = null
    private var sel = -1
    private var offline = false
    private var fahr = false
    private var askedPerm = false
    private var gpsFix: Location? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(size: Float, bold: Boolean = false) = TextView(this).apply {
        textSize = size
        typeface = if (bold) Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) else Typeface.MONOSPACE
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        fahr = Repo.useF(this)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(20), dp(12), dp(20), dp(4))
        }
        place = label(14f, true).apply { setOnClickListener { searchDialog() } }
        unit = label(14f, true).apply {
            setOnClickListener {
                fahr = !fahr
                Repo.prefs(this@MainActivity).edit().putBoolean("f", fahr).apply()
                render()
                WeatherWidget.updateAll(this@MainActivity)
            }
        }
        header.addView(place, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(unit)
        root.addView(header)

        sky = WeatherView(this)
        sky.setOnClickListener { sky.showData = !sky.showData }
        root.addView(sky, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        summary = label(15f, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(10), dp(16), dp(0))
            setOnClickListener { sel = -1; render() }
        }
        root.addView(summary)

        bar = DayBar(this)
        bar.onSelect = { sel = it; render() }
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(92)))

        status = label(11f).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), 0, dp(16), dp(14))
        }
        root.addView(status)
        setContentView(root)

        weather = Repo.load(this)
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
        refresh()
    }

    @Suppress("DEPRECATION")
    private fun render() {
        val w = weather
        if (w == null) {
            place.text = "TAP TO SET LOCATION"
            summary.text = "No data yet"
            return
        }
        val now = w.nowIndex()
        val span = w.frames.subList(now, minOf(now + 24, w.frames.size))
        val s = if (sel in span.indices) sel else -1
        val idx = now + maxOf(s, 0)
        val f = w.frames[idx]
        val night = !f.isDay
        val bg = if (night) c32(0xFF1C1C1E) else c32(0xFFF3F3F3)
        val fg = if (night) c32(0xFFEDEDED) else c32(0xFF222222)
        root.setBackgroundColor(bg)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = if (night) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        place.setTextColor(fg); unit.setTextColor(fg); summary.setTextColor(fg); status.setTextColor(fg)

        place.text = w.place.uppercase() + " ▾"
        unit.text = if (fahr) "°F" else "°C"

        val ms = System.currentTimeMillis() + (idx - now) * 3600000L
        val ph = Moon.phase(ms)
        val di = w.dayIndex(now)
        sky.frame = f
        sky.temp = U.t(f.temp, fahr).toString()
        sky.moonPhase = ph
        sky.info = listOf(
            "CLOUDS:${f.cloud}%", "RAIN:${f.prob}%", "TEMP:${U.t(f.temp, fahr)}",
            "FEELS:${U.t(f.feels, fahr)}", "HUM:${f.hum}%",
            "WIND:${U.speed(f.wind, fahr)} ${U.compass(f.windDir)}", "VIS:${U.dist(f.vis, fahr)}",
            "RISE:${U.hhmm(w.rise.getOrElse(di) { "" })}", "SET:${U.hhmm(w.sunset.getOrElse(di) { "" })}",
            "MOON:${Moon.name(ph)}"
        )

        bar.frames = span
        bar.labels = span.indices.map { if (it == 0) "NOW" else U.hourLabel(w.times[now + it]) }
        bar.selected = s
        bar.night = night
        bar.invalidate()

        val head = if (s >= 0) U.hourLabel(w.times[idx]) + " · " else ""
        summary.text = head + Wmo.desc(f.code).uppercase() + "\n" + rainText(w, now)

        val hi = U.t(w.hi.getOrElse(di) { 0.0 }, fahr)
        val lo = U.t(w.lo.getOrElse(di) { 0.0 }, fahr)
        status.text = (if (offline) "OFFLINE · SAVED DATA · " else "") +
            "H $hi°  L $lo°  · UPDATED ${ago(w.fetched)}"
    }

    private fun rainText(w: Weather, now: Int): String {
        val fr = w.frames
        val end = minOf(now + 24, fr.size)
        val word = { i: Int -> if (fr[i].snowing) "Snow" else "Rain" }
        if (fr[now].wet) {
            var j = now
            while (j < end && fr[j].wet) j++
            return if (j >= end) "${word(now)} all day" else "${word(now)} until ${U.hourLabel(w.times[j])}"
        }
        for (j in now until end) if (fr[j].wet) return "${word(j)} at ${U.hourLabel(w.times[j])}"
        return "No rain for 24 hours"
    }

    private fun ago(t: Long): String {
        val m = (System.currentTimeMillis() - t) / 60000
        return when {
            t == 0L -> "NEVER"
            m < 1 -> "JUST NOW"
            m < 60 -> "${m}M AGO"
            m < 1440 -> "${m / 60}H AGO"
            else -> "${m / 1440}D AGO"
        }
    }

    @SuppressLint("MissingPermission")
    private fun refresh() {
        val p = Repo.prefs(this)
        var lat: Double? = null
        var lon: Double? = null
        var name = ""
        if (p.getBoolean("manual", false)) {
            lat = p.getString("mlat", null)?.toDoubleOrNull()
            lon = p.getString("mlon", null)?.toDoubleOrNull()
            name = p.getString("mname", "") ?: ""
        } else if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            var best: Location? = gpsFix
            for (prov in lm.getProviders(true)) {
                val l = try { lm.getLastKnownLocation(prov) } catch (e: Exception) { null }
                if (l != null && (best == null || l.time > best.time)) best = l
            }
            if (best != null) {
                lat = best.latitude
                lon = best.longitude
            } else {
                requestSingle(lm)
            }
        } else if (!askedPerm) {
            askedPerm = true
            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 1)
            return
        }
        if (lat == null || lon == null) {
            val w = weather
            if (w != null) {
                lat = w.lat; lon = w.lon; name = w.place
            } else {
                return
            }
        }
        val la: Double = lat!!
        val lo: Double = lon!!
        Thread {
            var n = name
            if (n.isEmpty()) {
                n = try {
                    @Suppress("DEPRECATION")
                    val a = Geocoder(this, Locale.getDefault()).getFromLocation(la, lo, 1)
                    a?.firstOrNull()?.let { it.locality ?: it.subAdminArea }
                } catch (e: Exception) {
                    null
                } ?: weather?.place?.takeIf { it.isNotEmpty() } ?: "Current location"
            }
            val ok = Repo.fetch(this, la, lo, n)
            runOnUiThread {
                offline = !ok
                if (ok) weather = Repo.load(this)
                render()
                if (ok) WeatherWidget.updateAll(this)
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    @SuppressLint("MissingPermission")
    private fun requestSingle(lm: LocationManager) {
        val prov = when {
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            else -> return
        }
        try {
            lm.requestSingleUpdate(prov, object : LocationListener {
                override fun onLocationChanged(l: Location) { gpsFix = l; refresh() }
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            }, Looper.getMainLooper())
        } catch (e: Exception) {
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) refresh()
        else if (weather == null) searchDialog()
    }

    private fun searchDialog() {
        val et = EditText(this).apply { hint = "City name"; setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("Location")
            .setView(et)
            .setPositiveButton("Search") { _, _ ->
                val q = et.text.toString().trim()
                if (q.isNotEmpty()) Thread {
                    val g = Repo.geocode(q)
                    runOnUiThread {
                        if (g == null) {
                            Toast.makeText(this, "City not found (internet needed)", Toast.LENGTH_LONG).show()
                        } else {
                            Repo.prefs(this).edit().putBoolean("manual", true)
                                .putString("mlat", g.first.toString()).putString("mlon", g.second.toString())
                                .putString("mname", g.third).apply()
                            refresh()
                        }
                    }
                }.start()
            }
            .setNeutralButton("Use GPS") { _, _ ->
                Repo.prefs(this).edit().putBoolean("manual", false).apply()
                askedPerm = false
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
