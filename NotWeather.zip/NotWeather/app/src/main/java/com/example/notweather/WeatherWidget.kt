package com.example.notweather

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class WeatherWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val pending = goAsync()
        Thread {
            try {
                render(ctx, mgr, ids) // instant, from the offline cache
                val w = Repo.load(ctx)
                if (w != null && Repo.fetch(ctx, w.lat, w.lon, w.place)) render(ctx, mgr, ids)
            } catch (e: Exception) {
            } finally {
                pending.finish()
            }
        }.start()
    }

    companion object {
        fun updateAll(ctx: Context) {
            val m = AppWidgetManager.getInstance(ctx)
            val ids = m.getAppWidgetIds(ComponentName(ctx, WeatherWidget::class.java))
            if (ids.isNotEmpty()) render(ctx, m, ids)
        }

        fun render(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val w = Repo.load(ctx)
            val f = Repo.useF(ctx)
            val rv = RemoteViews(ctx.packageName, R.layout.widget_weather)
            if (w == null) {
                rv.setTextViewText(R.id.w_temp, "--")
                rv.setTextViewText(R.id.w_desc, "OPEN APP TO SET UP")
                rv.setTextViewText(R.id.w_hilo, "")
            } else {
                val now = w.nowIndex()
                val fr = w.frames[now]
                val di = w.dayIndex(now)
                rv.setTextViewText(R.id.w_temp, "${U.t(fr.temp, f)}°")
                rv.setTextViewText(R.id.w_desc, Wmo.desc(fr.code).uppercase())
                rv.setTextViewText(
                    R.id.w_hilo,
                    "H ${U.t(w.hi.getOrElse(di) { 0.0 }, f)}°  L ${U.t(w.lo.getOrElse(di) { 0.0 }, f)}°  ${w.place.uppercase()}"
                )
                rv.setImageViewBitmap(R.id.w_icon, Gfx.icon(fr, 160, Moon.phase(System.currentTimeMillis())))
                rv.setImageViewBitmap(
                    R.id.w_bar,
                    Gfx.bar(w.frames.subList(now, minOf(now + 24, w.frames.size)), 480, 36)
                )
            }
            val pi = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.w_root, pi)
            for (id in ids) mgr.updateAppWidget(id, rv)
        }
    }
}
