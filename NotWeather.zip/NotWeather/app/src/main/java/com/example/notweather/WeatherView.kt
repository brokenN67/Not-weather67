package com.example.notweather

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.sin

/** The animated "scene": sun/moon, giant temperature numeral, drifting clouds, rain, snow. */
class WeatherView(ctx: Context) : View(ctx) {
    var frame: Frame? = null
    var temp: String = ""
    var moonPhase: Double = 0.0
    var info: List<String> = emptyList()
    var showData = false

    private val t0 = System.nanoTime()
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val ip = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.MONOSPACE
        textSize = 11f * d
    }

    private fun hash(i: Int, k: Int): Float {
        var x = i * 374761393 + k * 668265263
        x = (x xor (x ushr 13)) * 1274126177.toInt()
        x = x xor (x ushr 16)
        return (x and 0xFFFF) / 65535f
    }

    override fun onDraw(c: Canvas) {
        val f = frame ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        val t = (System.nanoTime() - t0) / 1e9f
        val night = !f.isDay
        c.drawColor(if (night) c32(0xFF1C1C1E) else c32(0xFFF3F3F3))
        p.style = Paint.Style.FILL

        // sun or moon
        val cx = w * 0.64f
        val cy = h * 0.3f
        val r = minOf(w, h) * 0.2f
        if (night) Gfx.moon(c, p, cx, cy, r, moonPhase, c32(0xFF3A3A3C), c32(0xFFF2F2F2))
        else {
            p.color = c32(0xFFF4A3A3)
            c.drawCircle(cx, cy, r, p)
        }

        // giant temperature numeral
        tp.color = if (night) c32(0xFF8E8E93) else c32(0xFF4A4A4C)
        tp.textSize = h * 0.62f
        val tw = tp.measureText(temp)
        if (tw > w * 0.9f) tp.textSize = tp.textSize * (w * 0.9f / tw)
        c.drawText(temp, w / 2f, h * 0.55f + tp.textSize * 0.36f, tp)

        // clouds
        val n = Math.round(f.cloud / 100f * 6)
        val speed = 8f * d + f.wind.toFloat() * 1.5f * d
        p.color = if (night) (if (f.wet) c32(0xFF3F3F43) else c32(0xFF5C5C61))
        else (if (f.wet) c32(0xFF8E8E93) else c32(0xFFBFBFC4))
        for (i in 0 until n) {
            val s = h * 0.09f * (0.8f + hash(i, 1) * 0.7f)
            val span = w + s * 3
            val x = ((hash(i, 2) * span + t * speed * (0.6f + hash(i, 3) * 0.8f)) % span) - s * 1.5f
            val y = h * (0.12f + 0.38f * hash(i, 4))
            Gfx.cloud(c, p, x, y, s)
        }

        // rain / snow
        val dirx = (-sin(Math.toRadians(f.windDir.toDouble()))).toFloat()
        val slant = dirx * minOf(f.wind.toFloat() / 30f, 1.2f)
        if (f.wet && !f.snowing) {
            val cnt = (30 + f.precip * 60).coerceIn(30.0, 200.0).toInt()
            p.color = c32(0xFF3AA8FF)
            p.strokeWidth = 2.5f * d
            p.strokeCap = Paint.Cap.ROUND
            for (i in 0 until cnt) {
                val len = h * 0.04f * (0.7f + hash(i, 5))
                val sp = h * (0.8f + hash(i, 6) * 0.6f)
                val y = (hash(i, 7) * h + t * sp) % h
                var x = hash(i, 8) * w * 1.4f - w * 0.2f + slant * y
                x = ((x % w) + w) % w
                c.drawLine(x, y, x + slant * len, y + len, p)
            }
        } else if (f.snowing) {
            p.color = if (night) c32(0xFFF2F2F2) else c32(0xFF9AA0A6)
            for (i in 0 until 90) {
                val y = (hash(i, 7) * h + t * h * (0.12f + hash(i, 6) * 0.12f)) % h
                var x = hash(i, 8) * w + slant * y * 0.3f + sin(t + i.toFloat()) * 12f * d
                x = ((x % w) + w) % w
                c.drawCircle(x, y, (1.5f + hash(i, 5) * 2.5f) * d, p)
            }
        }

        // fog
        if (f.code == 45 || f.code == 48 || f.vis < 2000) {
            p.color = if (night) Color.argb(120, 90, 90, 95) else Color.argb(140, 235, 235, 238)
            c.drawRect(0f, 0f, w, h, p)
        }

        // lightning flash
        if (f.storm) {
            val ph = t % 5f
            if (ph < 0.12f || (ph > 0.25f && ph < 0.33f)) {
                p.color = Color.argb(110, 255, 255, 255)
                c.drawRect(0f, 0f, w, h, p)
            }
        }

        // tap-to-reveal data overlay
        if (showData) {
            ip.color = if (night) c32(0xFFDDDDDD) else c32(0xFF222222)
            val lh = ip.textSize * 1.5f
            val half = (info.size + 1) / 2
            for (i in info.indices) {
                val left = i < half
                val row = if (left) i else i - half
                ip.textAlign = if (left) Paint.Align.LEFT else Paint.Align.RIGHT
                val x = if (left) 16f * d else w - 16f * d
                val y = h - 16f * d - (half - 1 - row) * lh
                c.drawText(info[i], x, y, ip)
            }
        }
        postInvalidateOnAnimation()
    }
}

/** 24-hour strip: blue where it's wet. Touch or drag to scrub through the day. */
class DayBar(ctx: Context) : View(ctx) {
    var frames: List<Frame> = emptyList()
    var labels: List<String> = emptyList()
    var selected = -1
    var night = false
    var onSelect: ((Int) -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.MONOSPACE
        textSize = 10f * d
        textAlign = Paint.Align.CENTER
    }
    private val pad = 24f * d

    override fun onDraw(c: Canvas) {
        val n = frames.size
        if (n == 0) return
        val w = width.toFloat()
        val rect = RectF(pad, 36f * d, w - pad, 62f * d)
        Gfx.drawBar(c, frames, rect, if (night) c32(0xFF48484C) else c32(0xFFCFCFD3))
        val sw = rect.width() / n
        tp.color = if (night) c32(0xFFBBBBBB) else c32(0xFF555555)
        var i = 0
        while (i < n) {
            c.drawText(labels.getOrElse(i) { "" }, rect.left + (i + 0.5f) * sw, 82f * d, tp)
            i += 3
        }
        if (selected in 0 until n) {
            val x = rect.left + (selected + 0.5f) * sw
            p.style = Paint.Style.FILL
            p.color = Color.WHITE
            c.drawCircle(x, rect.centerY(), 10f * d, p)
            p.color = c32(0xFF3AA8FF)
            c.drawCircle(x, rect.centerY(), 5f * d, p)
            val bx = x.coerceIn(pad + 22f * d, w - pad - 22f * d)
            c.drawRoundRect(RectF(bx - 22f * d, 6f * d, bx + 22f * d, 28f * d), 11f * d, 11f * d, p)
            tp.color = Color.WHITE
            c.drawText(labels.getOrElse(selected) { "" }, bx, 21f * d, tp)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val n = frames.size
                if (n > 0) {
                    val idx = (((e.x - pad) / (width - 2 * pad)) * n).toInt().coerceIn(0, n - 1)
                    if (idx != selected) {
                        selected = idx
                        invalidate()
                        onSelect?.invoke(idx)
                    }
                }
            }
        }
        return true
    }
}
