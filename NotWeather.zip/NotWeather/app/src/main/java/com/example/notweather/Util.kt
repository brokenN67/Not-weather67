package com.example.notweather

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt

fun c32(v: Long): Int = v.toInt()

data class Frame(
    val temp: Double, val feels: Double, val hum: Int, val cloud: Int,
    val wind: Double, val windDir: Int, val precip: Double, val prob: Int,
    val code: Int, val isDay: Boolean, val vis: Double
) {
    val wet: Boolean get() = precip >= 0.1 || code in 51..99
    val snowing: Boolean get() = code in 71..77 || code in 85..86
    val storm: Boolean get() = code >= 95
}

class Weather(json: String) {
    private val o = JSONObject(json)
    val place: String = o.optString("place", "")
    val fetched: Long = o.optLong("fetched", 0L)
    val lat: Double = o.optDouble("latitude", 0.0)
    val lon: Double = o.optDouble("longitude", 0.0)
    private val offset: Int = o.optInt("utc_offset_seconds", 0)
    val times = ArrayList<String>()
    val frames = ArrayList<Frame>()
    val days = ArrayList<String>()
    val hi = ArrayList<Double>()
    val lo = ArrayList<Double>()
    val rise = ArrayList<String>()
    val sunset = ArrayList<String>()

    init {
        val h = o.getJSONObject("hourly")
        val t = h.getJSONArray("time")
        val temp = h.getJSONArray("temperature_2m")
        val feels = h.getJSONArray("apparent_temperature")
        val hum = h.getJSONArray("relative_humidity_2m")
        val cloud = h.getJSONArray("cloud_cover")
        val wind = h.getJSONArray("wind_speed_10m")
        val wdir = h.getJSONArray("wind_direction_10m")
        val pr = h.getJSONArray("precipitation")
        val prob = h.getJSONArray("precipitation_probability")
        val code = h.getJSONArray("weather_code")
        val day = h.getJSONArray("is_day")
        val vis = h.getJSONArray("visibility")
        for (i in 0 until t.length()) {
            times.add(t.getString(i))
            frames.add(
                Frame(
                    temp.optDouble(i, 0.0), feels.optDouble(i, 0.0), hum.optInt(i, 0),
                    cloud.optInt(i, 0), wind.optDouble(i, 0.0), wdir.optInt(i, 0),
                    pr.optDouble(i, 0.0), prob.optInt(i, 0), code.optInt(i, 0),
                    day.optInt(i, 1) == 1, vis.optDouble(i, 24000.0)
                )
            )
        }
        if (frames.isEmpty()) throw IllegalStateException("no data")
        val d = o.getJSONObject("daily")
        val dt = d.getJSONArray("time")
        for (i in 0 until dt.length()) {
            days.add(dt.getString(i))
            hi.add(d.getJSONArray("temperature_2m_max").optDouble(i, 0.0))
            lo.add(d.getJSONArray("temperature_2m_min").optDouble(i, 0.0))
            rise.add(d.getJSONArray("sunrise").optString(i, ""))
            sunset.add(d.getJSONArray("sunset").optString(i, ""))
        }
    }

    /** Index of the current hour, computed from the device clock so it works offline. */
    fun nowIndex(): Int {
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        val key = fmt.format(Date(System.currentTimeMillis() + offset * 1000L))
        val i = times.indexOfFirst { it.startsWith(key) }
        if (i >= 0) return i
        return if (key < times[0].take(13)) 0 else times.size - 1
    }

    fun dayIndex(now: Int): Int = days.indexOf(times[now].take(10)).coerceAtLeast(0)
}

object Wmo {
    fun desc(c: Int): String = when (c) {
        0 -> "Clear"
        1 -> "Mostly clear"
        2 -> "Partly cloudy"
        3 -> "Overcast"
        45, 48 -> "Fog"
        in 51..57 -> "Drizzle"
        in 61..65 -> "Rain"
        66, 67 -> "Freezing rain"
        in 71..77 -> "Snow"
        in 80..82 -> "Showers"
        85, 86 -> "Snow showers"
        in 95..99 -> "Thunderstorm"
        else -> "Unknown"
    }
}

object U {
    fun t(c: Double, f: Boolean): Int = (if (f) c * 9 / 5 + 32 else c).roundToInt()
    fun speed(k: Double, f: Boolean): Int = (if (f) k * 0.621371 else k).roundToInt()
    fun dist(m: Double, f: Boolean): String =
        if (f) String.format(Locale.US, "%.1fMI", m / 1609.34) else String.format(Locale.US, "%.1fKM", m / 1000)

    fun hhmm(iso: String): String {
        if (iso.length < 16) return "--"
        val h = iso.substring(11, 13).toInt()
        val hh = if (h % 12 == 0) 12 else h % 12
        return "$hh:${iso.substring(14, 16)}${if (h < 12) "AM" else "PM"}"
    }

    fun hourLabel(iso: String): String {
        if (iso.length < 13) return "--"
        val h = iso.substring(11, 13).toInt()
        val hh = if (h % 12 == 0) 12 else h % 12
        return "$hh${if (h < 12) "AM" else "PM"}"
    }

    fun compass(d: Int): String {
        val n = arrayOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
        return n[(((d % 360) + 22) / 45) % 8]
    }
}

object Moon {
    fun phase(ms: Long): Double {
        val syn = 29.530588853
        val d = (ms - 947182440000L) / 86400000.0
        val p = (d % syn) / syn
        return if (p < 0) p + 1 else p
    }

    fun name(p: Double): String = when {
        p < 0.03 || p > 0.97 -> "NEW"
        p < 0.22 -> "WAX CRESCENT"
        p < 0.28 -> "FIRST QTR"
        p < 0.47 -> "WAX GIBBOUS"
        p < 0.53 -> "FULL"
        p < 0.72 -> "WAN GIBBOUS"
        p < 0.78 -> "LAST QTR"
        else -> "WAN CRESCENT"
    }
}

object Repo {
    fun prefs(c: Context) = c.getSharedPreferences("weather", Context.MODE_PRIVATE)

    fun useF(c: Context): Boolean = prefs(c).getBoolean("f", Locale.getDefault().country == "US")

    fun load(c: Context): Weather? = try {
        prefs(c).getString("json", null)?.let { Weather(it) }
    } catch (e: Exception) {
        null
    }

    private fun http(u: String): String {
        val con = URL(u).openConnection() as HttpURLConnection
        con.connectTimeout = 10000
        con.readTimeout = 15000
        try {
            return con.inputStream.bufferedReader().readText()
        } finally {
            con.disconnect()
        }
    }

    /** Downloads a fresh forecast and saves it for offline use. Returns true on success. */
    fun fetch(c: Context, lat: Double, lon: Double, place: String): Boolean = try {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&hourly=temperature_2m,apparent_temperature,relative_humidity_2m,cloud_cover,wind_speed_10m," +
            "wind_direction_10m,precipitation,precipitation_probability,weather_code,is_day,visibility" +
            "&daily=temperature_2m_max,temperature_2m_min,sunrise,sunset&timezone=auto&forecast_days=3"
        val o = JSONObject(http(url))
        o.put("place", place)
        o.put("fetched", System.currentTimeMillis())
        val s = o.toString()
        Weather(s) // validate before saving
        prefs(c).edit().putString("json", s).apply()
        true
    } catch (e: Exception) {
        false
    }

    fun geocode(q: String): Triple<Double, Double, String>? = try {
        val o = JSONObject(http("https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + URLEncoder.encode(q, "UTF-8")))
        val r = o.optJSONArray("results")?.getJSONObject(0)
        if (r == null) null else {
            val a = r.optString("admin1", "")
            Triple(r.getDouble("latitude"), r.getDouble("longitude"), r.getString("name") + if (a.isEmpty()) "" else ", $a")
        }
    } catch (e: Exception) {
        null
    }
}

object Gfx {
    fun cloud(c: Canvas, p: Paint, x: Float, y: Float, s: Float) {
        c.drawCircle(x, y, s * 0.5f, p)
        c.drawCircle(x + s * 0.55f, y - s * 0.28f, s * 0.68f, p)
        c.drawCircle(x + s * 1.2f, y, s * 0.5f, p)
        c.drawCircle(x + s * 0.6f, y + s * 0.12f, s * 0.5f, p)
    }

    fun moon(c: Canvas, p: Paint, cx: Float, cy: Float, r: Float, ph: Double, dark: Int, light: Int) {
        p.style = Paint.Style.FILL
        p.color = dark
        c.drawCircle(cx, cy, r, p)
        val cv = cos(2 * Math.PI * ph)
        val k = (1 - cv) / 2
        val waxing = ph < 0.5
        c.save()
        c.clipRect(if (waxing) RectF(cx, cy - r, cx + r, cy + r) else RectF(cx - r, cy - r, cx, cy + r))
        p.color = light
        c.drawCircle(cx, cy, r, p)
        c.restore()
        val a = r * abs(cv).toFloat()
        p.color = if (k < 0.5) dark else light
        c.drawOval(RectF(cx - a, cy - r, cx + a, cy + r), p)
    }

    fun drawBar(c: Canvas, frames: List<Frame>, rect: RectF, gray: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val path = Path()
        path.addRoundRect(rect, rect.height() / 2, rect.height() / 2, Path.Direction.CW)
        c.save()
        c.clipPath(path)
        val n = frames.size.coerceAtLeast(1)
        val sw = rect.width() / n
        for (i in frames.indices) {
            p.color = if (frames[i].wet) c32(0xFF3AA8FF) else gray
            c.drawRect(rect.left + i * sw, rect.top, rect.left + (i + 1) * sw + 1f, rect.bottom, p)
        }
        c.restore()
    }

    fun bar(frames: List<Frame>, w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        drawBar(Canvas(b), frames, RectF(0f, 0f, w.toFloat(), h.toFloat()), c32(0xFF5A5A5E))
        return b
    }

    fun icon(f: Frame, size: Int, ph: Double): Bitmap {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val s = size.toFloat()
        if (f.cloud < 85) {
            if (f.isDay) {
                p.color = c32(0xFFF4A3A3)
                c.drawCircle(s * 0.62f, s * 0.36f, s * 0.24f, p)
            } else {
                moon(c, p, s * 0.62f, s * 0.36f, s * 0.24f, ph, c32(0xFF4A4A4E), c32(0xFFF2F2F2))
            }
        }
        if (f.cloud >= 60) {
            p.color = c32(0xFFA8A8AD)
            cloud(c, p, s * 0.45f, s * 0.42f, s * 0.22f)
        }
        if (f.cloud >= 20 || f.wet) {
            p.color = c32(0xFFD0D0D4)
            cloud(c, p, s * 0.22f, s * 0.52f, s * 0.28f)
        }
        if (f.wet) {
            p.color = c32(0xFF3AA8FF)
            p.strokeWidth = s * 0.03f
            p.strokeCap = Paint.Cap.ROUND
            for (i in 0..3) {
                val x = s * (0.28f + 0.14f * i)
                c.drawLine(x, s * 0.78f, x - s * 0.04f, s * 0.9f, p)
            }
        }
        return b
    }
}
