# Not Weather (Android)

Weather app inspired by Not Boring Weather. Animated scene (sun/moon, giant temperature numeral,
clouds, rain, snow, lightning, fog), scrubbable 24-hour bar, tap-the-scene to see raw data,
home-screen widget, and offline mode (last forecast is cached; the current hour is worked out
from the saved 3-day forecast). Data: Open-Meteo (free, no API key).

## Get the APK (no Android Studio needed)
1. Make a free GitHub account, create a new repository.
2. Upload ALL of this folder's contents, including the hidden `.github` folder (easiest from a PC:
   unzip, then drag the files into the repo's "Add file > Upload files" page).
3. Open the repo's **Actions** tab > "Build APK" > wait ~4 min for the green tick.
4. Open the run > **Artifacts** > download `NotWeather-apk` (a zip) > extract `app-debug.apk`.
5. Install it on your phone (allow "install unknown apps" for your browser/file manager).

## Or with Android Studio
File > Open this folder > Build > Build APK(s). Min Android 8.0 (API 26).

## Use
- First launch: allow location, or tap the city name at the top and search a city.
- Tap the big scene: shows raw weather data. Tap the °C/°F toggle to switch units.
- Touch/drag the bar at the bottom to preview any hour. Tap the text above it to return to now.
- Widget: long-press home screen > Widgets > Not Weather. Updates about every 30 min.
